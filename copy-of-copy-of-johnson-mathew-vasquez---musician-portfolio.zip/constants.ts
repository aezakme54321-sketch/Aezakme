import { EducationItem, SkillCategory, QuoteData } from './types';

export const PERSONAL_INFO = {
  name: "JOHNSON MATHEW VASQUEZ",
  tagline: "MUSICIAN | FILMMAKER | DEVELOPER",
  location: "Calumpang, Molo",
  aboutShort: "Based in Calumpang Molo, I’m a musician and filmmaker who finds rhythm in both sound and code. I enjoy the process of learning new instruments, building software, and telling stories through a lens.",
  aboutFact: "I’m simply a student of technology and the arts, always looking to grow. Whether I'm debugging code, framing a shot, or composing a melody, I strive to find the harmony in every project.",
};

export const EDUCATION_HISTORY: EducationItem[] = [
  {
    school: "University of Iloilo",
    detail: "Senior High School Graduate (GAS-CRIM)",
    year: "2025"
  },
  {
    school: "Calinog National Comprehensive High School",
    detail: "JHS Graduate",
    year: "2023"
  },
  {
    school: "Calinog Central Elementary School",
    detail: "Elementary Graduate",
    year: "2019"
  }
];

export const SKILLS: SkillCategory[] = [
  {
    title: "CREATIVE & VISUAL",
    items: ["Filmmaking & Storytelling", "Drums & Percussion", "Music Composition", "Video Editing"]
  },
  {
    title: "TECH & LIFESTYLE",
    items: ["Software Development", "Culinary Arts (Cooking)", "Effective Communication", "Leadership"]
  }
];

export const GOALS_TEXT = "My mission is to fuse technology and art, creating experiences that resonate on a deeper level. I strive for independence, building a life where I can tell stories, build innovative tools, and orchestrate sounds that move people.";

export const FAVORITE_QUOTE: QuoteData = {
  text: "The universe does not carry debts. It always returns back to you what you gave it.",
  author: "Drishti Bablani"
};