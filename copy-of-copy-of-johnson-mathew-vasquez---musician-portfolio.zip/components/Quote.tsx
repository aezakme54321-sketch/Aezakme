import React from 'react';
    import { QuoteData } from '../types';
    
    export const Quote: React.FC<{ data: QuoteData }> = ({ data }) => {
      return (
        <div className="mt-16 relative py-10 px-6 border-y border-white/10 hover:border-accent/50 transition-colors duration-500 group text-center">
          <p className="text-2xl md:text-4xl font-display font-bold text-white mb-6 leading-tight">
            "{data.text}"
          </p>
          <div className="flex justify-center items-center gap-3">
            <div className="h-[1px] w-8 bg-accent"></div>
            <span className="text-sm font-sans uppercase tracking-widest text-muted group-hover:text-white transition-colors">
              {data.author}
            </span>
            <div className="h-[1px] w-8 bg-accent"></div>
          </div>
        </div>
      );
    };