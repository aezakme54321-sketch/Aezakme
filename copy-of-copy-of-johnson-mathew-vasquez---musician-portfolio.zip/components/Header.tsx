import React from 'react';

interface HeaderProps {
  name: string;
  tagline: string;
}

export const Header: React.FC<HeaderProps> = ({ name, tagline }) => {
  return (
    <header className="flex flex-col items-start justify-center min-h-[40vh] mb-20 animate-fade-in relative">
      {/* Decorative Line */}
      <div className="w-12 h-1 bg-accent mb-8"></div>
      
      <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-extrabold text-white leading-[0.9] mb-6 tracking-tighter uppercase">
        {name.split(' ').map((word, i) => (
          <span key={i} className="block">{word}</span>
        ))}
      </h1>
      
      <p className="text-sm md:text-base font-sans tracking-[0.2em] uppercase text-muted font-medium border-l border-white/20 pl-4 ml-1">
        {tagline}
      </p>

      {/* Background Glow */}
      <div className="absolute top-1/2 right-0 w-64 h-64 bg-accent/5 rounded-full blur-[100px] pointer-events-none -z-10"></div>
    </header>
  );
};