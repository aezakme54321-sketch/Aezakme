import React, { ReactNode } from 'react';

interface SectionProps {
  id?: string;
  title: string;
  children: ReactNode;
  className?: string;
}

export const Section: React.FC<SectionProps> = ({ id, title, children, className = "" }) => {
  return (
    <section id={id} className={`mb-24 scroll-mt-32 ${className}`}>
      <div className="flex items-baseline gap-4 mb-10 group cursor-default">
        <span className="text-accent font-display font-bold text-lg opacity-50 group-hover:opacity-100 transition-opacity">
          //
        </span>
        <h2 className="text-3xl md:text-4xl font-display font-bold text-white uppercase tracking-tight group-hover:text-white transition-colors">
          {title}
        </h2>
      </div>
      <div className="font-sans text-gray-300 text-lg leading-relaxed pl-0 md:pl-8 border-l border-white/5 md:border-white/10 ml-2 md:ml-0">
        {children}
      </div>
    </section>
  );
};