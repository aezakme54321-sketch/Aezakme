import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";

export const SongGenerator: React.FC = () => {
  const [mood, setMood] = useState('');
  const [lyrics, setLyrics] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const generateLyrics = async () => {
    if (!mood.trim()) return;
    if (!process.env.API_KEY) {
      setError("API Key missing. Please set the API_KEY environment variable.");
      return;
    }

    setIsLoading(true);
    setError('');
    setLyrics('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Write a creative short verse and a chorus for a song about "${mood}". 
      Make it poetic, rhythmic, and evocative. Format it with [Verse] and [Chorus] labels. Keep it under 150 words.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setLyrics(response.text || "Could not generate lyrics. Try again!");
    } catch (err) {
      console.error("Error generating lyrics:", err);
      setError("Failed to generate lyrics. The creative juices are jammed.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="mt-16 bg-gradient-to-br from-zinc-900 to-black p-1 border border-zinc-800 rounded-lg shadow-2xl relative overflow-hidden group">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none"></div>
      <div className="bg-rock-panel p-6 md:p-8 rounded-md h-full flex flex-col relative z-10">
        <h3 className="text-xl font-mono uppercase tracking-widest text-white mb-6 flex items-center gap-2">
          <span className="text-white animate-pulse">●</span> Creative Flow
        </h3>
        
        <p className="font-sans text-zinc-400 mb-6 text-sm">
          Need a spark? Enter a mood, theme, or concept, and let AI draft a lyrical idea for you.
        </p>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <input
            type="text"
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            placeholder="E.g., Digital solitude, City lights, Nostalgia..."
            className="flex-1 bg-black border border-zinc-700 text-white p-3 font-mono focus:outline-none focus:border-zinc-500 transition-colors placeholder-zinc-700 rounded-sm"
            onKeyDown={(e) => e.key === 'Enter' && generateLyrics()}
          />
          <button
            onClick={generateLyrics}
            disabled={isLoading || !mood}
            className="bg-zinc-100 text-black font-mono font-bold uppercase tracking-widest px-6 py-3 hover:bg-zinc-300 disabled:opacity-50 disabled:cursor-not-allowed transition-colors rounded-sm"
          >
            {isLoading ? 'Creating...' : 'Generate'}
          </button>
        </div>

        {error && (
          <p className="text-red-400 font-mono text-sm mb-4">{error}</p>
        )}

        {lyrics && (
          <div className="bg-black p-6 border-l-4 border-white rounded-r font-mono text-zinc-300 whitespace-pre-wrap animate-fade-in shadow-inner">
            {lyrics}
          </div>
        )}
      </div>
    </div>
  );
};