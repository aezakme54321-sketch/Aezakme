import React from 'react';
import { Section } from './components/Section';
import { Header } from './components/Header';
import { Quote } from './components/Quote';
import { 
  PERSONAL_INFO, 
  EDUCATION_HISTORY, 
  SKILLS, 
  GOALS_TEXT, 
  FAVORITE_QUOTE 
} from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center selection:bg-accent selection:text-white">
      <div className="w-[85%] max-w-[900px] py-12 md:py-24">
        
        <Header name={PERSONAL_INFO.name} tagline={PERSONAL_INFO.tagline} />

        <main className="animate-fade-in [animation-delay:200ms] opacity-0" style={{ animationFillMode: 'forwards' }}>
          
          {/* About Section */}
          <Section id="about" title="About">
            <div className="grid md:grid-cols-[2fr_1fr] gap-8">
              <p className="text-lg md:text-xl font-light text-gray-300">
                {PERSONAL_INFO.aboutShort}
              </p>
              <div className="text-sm font-mono text-muted border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-6">
                <span className="text-accent block mb-2 text-xs uppercase tracking-widest font-bold">The Vibe</span>
                {PERSONAL_INFO.aboutFact}
              </div>
            </div>
          </Section>

          {/* Education Section */}
          <Section id="education" title="Education">
            <div className="space-y-8">
              {EDUCATION_HISTORY.map((edu, index) => (
                <div key={index} className="group relative pl-4 hover:pl-6 transition-all duration-300 border-l-2 border-white/5 hover:border-accent">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-end mb-1">
                    <h3 className="text-xl text-white font-display font-bold uppercase tracking-wide">
                      {edu.school}
                    </h3>
                    {edu.year && (
                      <span className="font-mono text-xs text-accent bg-accent/10 px-2 py-1 rounded">
                        {edu.year}
                      </span>
                    )}
                  </div>
                  <p className="text-muted font-sans font-light">
                    {edu.detail}
                  </p>
                </div>
              ))}
            </div>
          </Section>

          {/* Skills Section */}
          <Section id="skills" title="Hobbies & Skills">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {SKILLS.map((category, idx) => (
                <div key={idx} className="bg-white/5 hover:bg-white/10 p-6 rounded-sm transition-all duration-300 border border-white/5 hover:border-white/20">
                  <h3 className="font-display font-bold text-white uppercase mb-6 tracking-wider border-b border-white/10 pb-2">
                    {category.title}
                  </h3>
                  <ul className="space-y-3">
                    {category.items.map((skill, sIdx) => (
                      <li key={sIdx} className="flex items-center text-gray-400 group">
                        <span className="w-1.5 h-1.5 bg-zinc-800 mr-3 group-hover:bg-accent transition-colors duration-300"></span>
                        <span className="group-hover:text-white transition-colors duration-300 font-light">
                          {skill}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </Section>

          {/* Goals Section */}
          <Section id="goals" title="Vision">
            <p className="text-lg md:text-xl font-light text-gray-300 mb-12">
              {GOALS_TEXT}
            </p>
            <Quote data={FAVORITE_QUOTE} />
          </Section>

        </main>

        <div className="h-32"></div>

      </div>
    </div>
  );
};

export default App;