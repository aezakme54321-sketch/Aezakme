export interface EducationItem {
  school: string;
  detail: string;
  year?: string;
}

export interface SkillCategory {
  title: string;
  items: string[];
}

export interface QuoteData {
  text: string;
  author: string;
}

export interface SocialLink {
  label: string;
  url: string;
}